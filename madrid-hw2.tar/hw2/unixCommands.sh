#!/bin/bash

#dd: copy a file, converting and formatting according to the operands
echo 'dd command'
dd if=file1.txt of=file2.txt conv=ucase
echo ""
#find: find searches the dierectory for files based upon what is inputed in the command
echo 'find command'
find /hw2 -name "*.txt"
echo ""
#file:tests each argument in an attempt to classify it
echo 'file command'
file file1.txt
echo ""
#fuser:display the PID's of processes using the specified files or file systems.
echo 'fuser command'
fuser /hw2
echo ""
#grep: searches the named input FILE for lines containing a match to given pattern
echo 'grep command'
grep 'TEST' file1.txt
echo ""
#host: is a simple utility for performing DNS lookups
echo 'host command'
host google.com
echo ""
#ldd: prints the shared objects required by each program or shared object specified on the command line
echo 'ldd command'
ldd /bin/cp
echo ""
#lsof: lists on its standard output file information about files opened by processes
echo 'lsof command'
lsof /var/log/syslog | more
echo ""
#mount: serves to attach the filesystem found on some device to the big file tree
mount
#ps: displays information about a selection of the active processes
echo 'ps command'
ps | more
echo ""
#pkill: will kill processes by a full or partial name
echo 'pkil command'
pkill -u josh
echo ""
#netstat: prints the information about the linux networking subsystem.
echo 'netstat command'
netstat -r
echo ""
#renice: alters the scheduling priority of one or more running processes.
echo 'renice comamnd'
renice -v
echo ""
#rsync: file copy tool to copy from on host to any remote shell
echo 'rsync command'
rsync -zvh /hw2 /hw2/test
echo ""
#time:returns time as the number of seconds since the epoch
echo 'time command'
time df | more
echo ""
#ssh: a program for logging into a remote machine and for executing commands on a remote machine
echo 'ssh command'
echo 'change this command to your user name for testing purpose'
#ssh -X jmadr004@bolt.cs.ucr.edu
echo ""
#stat: returns information about a file
echo 'stat command'
stat /var/log/syslog
echo ""
#strace: useful diagnostic, instructional, and debugging tool
strace -e open ls
echo 'check file3.txt for strace ls info'
echo ""
#uname:print certain system information
echo 'uname command'
uname -s
echo ""
#wget: used for non-interactive download of files from the web
echo 'wget command'
wget --version
echo ""
